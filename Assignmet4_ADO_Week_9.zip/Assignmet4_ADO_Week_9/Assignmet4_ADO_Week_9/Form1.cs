﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignmet4_ADO_Week_9
{
    public partial class Form1 : Form
    {
        List<Player> availablePlayersList;
        List<Player> playersInTeam;
        List<Teams> listOfTeams;
        
        public Form1()
        {
            InitializeComponent();
            availablePlayersList = new List<Player>();
            playersInTeam = new List<Player>();
            listOfTeams = new List<Teams>();
        }
        //everything related to adding
        private void btnAddPlayer_Click(object sender, EventArgs e)
        {
            if(txtbName.Text == string.Empty || txtbSemester.Text == string.Empty ||
                cbPosition.SelectedItem == null)
            {
                MessageBox.Show("Please fill all of the information to add a player!");
            }
            else
            {
                string name = txtbName.Text;
                string semester = txtbSemester.Text;
                string position = cbPosition.SelectedItem.ToString();

                Player currentPlayer = new Player(name, semester, position);
                bool isAdded = WasItAdded(availablePlayersList, currentPlayer);
                bool isAddedInTeam = WasItAdded(playersInTeam, currentPlayer);
                if (!isAdded && !isAddedInTeam)
                {
                    availablePlayersList.Add(currentPlayer);
                }
                showAvailablePlayers();
                txtbName.Text = string.Empty;
                txtbSemester.Text = string.Empty;
            }
            
        }

        private void btnAddToTeam_Click(object sender, EventArgs e)
        {
            if(playersInTeam.Count == 11)
            {
                MessageBox.Show("You have reached the maximum player limit. \n" +
                    " Please remove a player to continue.");
            }
            else if (getSelectedAvailablePlayer() != null)
            {
                Player PlayerToAddTeam = getSelectedAvailablePlayer();
                playersInTeam.Add(PlayerToAddTeam);
                availablePlayersList.Remove(PlayerToAddTeam);
                showAllPlayers();
            }
        }

        private void btnAddAllToTeam_Click(object sender, EventArgs e)
        {
            if(availablePlayersList.Count + playersInTeam.Count > 11)
            {
                MessageBox.Show("You cannot add all players!\n" +
                    "There cannot be more than 11 players in a team!");
            }
            else
            {
                foreach (Player player in availablePlayersList)
                {
                    playersInTeam.Add(player);
                }
                availablePlayersList.Clear();

                showAllPlayers();
            } 
        }

        //everything related to removing
        private void btnRemovePlayer_Click(object sender, EventArgs e)
        {
            if(getSelectedAvailablePlayer() != null)
            {
                Player currentPlayer = getSelectedAvailablePlayer();
                foreach (Player player in availablePlayersList)
                {
                    if (player.GetHashCode() == currentPlayer.GetHashCode())
                    {
                        availablePlayersList.Remove(player);
                        break;
                    }
                }
                showAvailablePlayers();
            }            
            
        }

        private void btnRemoveFromTeam_Click(object sender, EventArgs e)
        {
            if(getSelectedTeamPlayer() != null)
            {
                Player currentPlayer = getSelectedTeamPlayer();
                foreach (Player player in playersInTeam)
                {
                    if (player.GetHashCode() == currentPlayer.GetHashCode())
                    {
                        playersInTeam.Remove(player);
                        availablePlayersList.Add(player);
                        break;
                    }
                }
                showAllPlayers();
            }
        }

        private void btnRemoveAllFromTeam_Click(object sender, EventArgs e)
        {
            foreach (Player player in playersInTeam)
            {
                availablePlayersList.Add(player);
            }
            playersInTeam.Clear();

            showAllPlayers();
        }
        //editing players information
        private void btnEditPlayer_Click(object sender, EventArgs e)
        {
            if (getSelectedAvailablePlayer() != null)
            {
                Player selectedPlayer = getSelectedAvailablePlayer();
                selectedPlayer.Semester = txtbSemester.Text;
                selectedPlayer.Position = cbPosition.SelectedItem.ToString();
                txtbName.Text = string.Empty;
                txtbSemester.Text = string.Empty;

                showAvailablePlayers();
            }
        }
        // also related to the editing button
        private void lbshowPlayers_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (getSelectedAvailablePlayer() != null)
            {
                Player selectedPlayer = getSelectedAvailablePlayer();
                txtbName.Text = selectedPlayer.Name;
                txtbSemester.Text = selectedPlayer.Semester;
                cbPosition.SelectedItem = selectedPlayer.Position;
            }
        }
        //adding more functionality 
        private void btnCreateTeam_Click(object sender, EventArgs e)
        {
            int enteredPositionAtck = checkCountPosition("Attacker");
            int enteredPositionQuatrb = checkCountPosition("Quarterback");
            int enteredPositionGkpr = checkCountPosition("Goalkeeper");
            string teamName = txtbTeamName.Text;
            if (playersInTeam.Count < 11)
            {
                MessageBox.Show("You don't have enough players to create a team.");
            }
            else if (cbFormation.SelectedItem == null)
            {
                MessageBox.Show("Please select a formation.");
            }
            else if (txtbTeamName.Text == string.Empty)
            {
                MessageBox.Show("Please add a name to your team!");
            }
            else if (checkIfNameUsed(teamName))
            {
                MessageBox.Show("Please choose a different name. \n This name is already taken.");
            }
            else
            {
                string formation = cbFormation.SelectedItem.ToString();
                int getFormationGkpr = getRequiredFormationPart(0);
                int getFormationQuatrb = getRequiredFormationPart(1);
                int getFormationAtck = getRequiredFormationPart(2);
                if (getFormationAtck == enteredPositionAtck && getFormationQuatrb == enteredPositionQuatrb
                    && getFormationGkpr == enteredPositionGkpr)
                {
                    Teams team = new Teams(teamName, formation);
                    foreach (Player player in playersInTeam)
                    {
                        team.addPlayer(player);
                    }
                    listOfTeams.Add(team);
                    playersInTeam.Clear();
                    txtbTeamName.Text = string.Empty;
                    showAllPlayers();
                    showTeams();
                }
                else
                {
                    MessageBox.Show("Your team doesn't fit the selected formation!");
                }
            }
        }
        //helping methods
        private Player getSelectedAvailablePlayer()
        {
            if (lbshowPlayers.SelectedItem != null)
            {
                string currentPosition = lbshowPlayers.SelectedItem.ToString();
                int selectedNumber = Convert.ToInt32(currentPosition.Split('.')[0]);
                Player selectedAvailablePlayer = availablePlayersList[selectedNumber - 1];
                return selectedAvailablePlayer;
            }
            else
            {
                return null;
            }
        }
        private Player getSelectedTeamPlayer()
        {
            if (lbShowPlayersInTeam.SelectedItem != null)
            {
                string currentPosition = lbShowPlayersInTeam.SelectedItem.ToString();
                int selectedNumber = Convert.ToInt32(currentPosition.Split('.')[0]);
                return playersInTeam[selectedNumber - 1];
            }
            else
            {
                return null;
            }
        }

        private bool WasItAdded(List<Player> currentList, Player currentPlayer)
        {
            foreach (Player player in currentList)
            {
                if (player.Name == currentPlayer.Name)
                {
                    MessageBox.Show("This player is already added!");
                    return true;
                }
            }
            return false;
        }

        private bool checkIfNameUsed(string name)
        {
            foreach (Teams teams in listOfTeams)
            {
                if (teams.Name == name)
                {
                    return true;
                }
            }
            return false;
        }

        private int checkCountPosition(string currentPosition)
        {
            int counter = 0;
            foreach (Player player in playersInTeam)
            {
                if (player.Position == currentPosition)
                {
                    counter++;
                }
            }
            return counter;
        }

        private int getRequiredFormationPart(int i)
        {
            string currentFormation = cbFormation.SelectedItem.ToString();
            string getFormationPart = currentFormation.Split('-')[i];
            getFormationPart = getFormationPart.Trim();
            int finalFormationPart = Convert.ToInt32(getFormationPart);
            return finalFormationPart;
        }
        //everything related to displaying information
        private void showAllPlayers()
        {
            showAvailablePlayers();
            showTeamPlayers();
        }
        private void showAvailablePlayers()
        {
            lbshowPlayers.Items.Clear();
            int countPositionInTable = 0;
            foreach (Player player in availablePlayersList)
            {
                countPositionInTable++;
                lbshowPlayers.Items.Add(countPositionInTable + ". " + player);

            }
        }

        private void showTeamPlayers()
        {
            lbShowPlayersInTeam.Items.Clear();
            int countPositionInTable = 0;
            foreach (Player player in playersInTeam)
            {
                countPositionInTable++;
                lbShowPlayersInTeam.Items.Add(countPositionInTable + ". " + player);

            }
        }
        private void showTeams()
        {
            lbAllTeams.Items.Clear();
            foreach (Teams team in listOfTeams)
            {
                lbAllTeams.Items.Add(team.Name);
            }
        }

        private void btnViewSelectedTeam_Click(object sender, EventArgs e)
        {
            if (lbAllTeams.SelectedItem != null)
            {
                lbViewPlayersInTeam.Items.Clear();
                string selectedTeam = lbAllTeams.SelectedItem.ToString();
                foreach (Teams team in listOfTeams)
                {
                    if (team.Name == selectedTeam)
                    {
                        foreach (Player player in team.Team)
                        {
                            lbViewPlayersInTeam.Items.Add(player);
                        }//////
                        lbViewPlayersInTeam.Items.Add("Formation:");
                        lbViewPlayersInTeam.Items.Add(team.Formation);
                        break;
                    }
                }
                lbViewPlayersInTeam.Visible = true;
                btnClearView.Visible = true;
            }
        }

        private void btnClearView_Click(object sender, EventArgs e)
        {
            lbViewPlayersInTeam.Items.Clear();
            lbViewPlayersInTeam.Visible = false;
            btnClearView.Visible = false;
        }
        //the things I don't touch
        private void btnAddPlayer_MouseHover(object sender, EventArgs e)
        { 
        }

        private void lbshowPlayers_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        
    }
}
