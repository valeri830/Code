﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignmet4_ADO_Week_9
{
    class Teams
    {
        private string name;
        private string formation;
        private List<Player> team;

        public Teams(string name, string formation)
        {
            this.name = name;
            this.formation = formation;
            team = new List<Player>();
        }        

        public string Name
        {
            get { return name; }

        }
        public string Formation
        {
            get { return formation; }
        }

        public List<Player> Team
        {
            get { return team; }
        }

        public void addPlayer(Player player)
        {
            this.team.Add(player);
        }
        
    }
}
