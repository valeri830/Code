﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignmet4_ADO_Week_9
{
    class Player
    {
        private string name;
        private string semester;
        private string position;

        public Player(string name, string semester, string position)
        {
            this.name = name;
            this.semester = semester;
            this.position = position;
        }

        public string Name
        {
             get { return name; }
            set { name = value; }
        }

        public string Semester
        {
            get { return semester; }
            set { semester = value; }
        }

        public string Position
        {
            get { return position; }
            set { position = value; }
        }        

        public override int GetHashCode()
        {
            int hashCode = 0 ;
            hashCode = hashCode + Name.GetHashCode(); ;
            hashCode = hashCode + Semester.GetHashCode();
            hashCode = hashCode + Position.GetHashCode();
            return hashCode;
        }

        public override string ToString()
        {
            return name + " - " + semester + " - " + position;
        }

        
    }
}
