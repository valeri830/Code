﻿namespace Assignmet4_ADO_Week_9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtbName = new System.Windows.Forms.TextBox();
            this.txtbSemester = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbshowPlayers = new System.Windows.Forms.ListBox();
            this.btnAddPlayer = new System.Windows.Forms.Button();
            this.btnRemovePlayer = new System.Windows.Forms.Button();
            this.btnEditPlayer = new System.Windows.Forms.Button();
            this.lbShowPlayersInTeam = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAddToTeam = new System.Windows.Forms.Button();
            this.cbPosition = new System.Windows.Forms.ComboBox();
            this.btnRemoveFromTeam = new System.Windows.Forms.Button();
            this.btnRemoveAllFromTeam = new System.Windows.Forms.Button();
            this.btnAddAllToTeam = new System.Windows.Forms.Button();
            this.btnCreateTeam = new System.Windows.Forms.Button();
            this.cbFormation = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbAllTeams = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnViewSelectedTeam = new System.Windows.Forms.Button();
            this.lbViewPlayersInTeam = new System.Windows.Forms.ListBox();
            this.btnClearView = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbTeamName = new System.Windows.Forms.TextBox();
            this.ButtonInfo = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // txtbName
            // 
            this.txtbName.Location = new System.Drawing.Point(83, 49);
            this.txtbName.Margin = new System.Windows.Forms.Padding(4);
            this.txtbName.Name = "txtbName";
            this.txtbName.Size = new System.Drawing.Size(132, 22);
            this.txtbName.TabIndex = 1;
            // 
            // txtbSemester
            // 
            this.txtbSemester.Location = new System.Drawing.Point(239, 49);
            this.txtbSemester.Margin = new System.Windows.Forms.Padding(4);
            this.txtbSemester.Name = "txtbSemester";
            this.txtbSemester.Size = new System.Drawing.Size(132, 22);
            this.txtbSemester.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(123, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(277, 30);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Semester";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(440, 30);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Position";
            // 
            // lbshowPlayers
            // 
            this.lbshowPlayers.FormattingEnabled = true;
            this.lbshowPlayers.ItemHeight = 16;
            this.lbshowPlayers.Location = new System.Drawing.Point(230, 107);
            this.lbshowPlayers.Margin = new System.Windows.Forms.Padding(4);
            this.lbshowPlayers.Name = "lbshowPlayers";
            this.lbshowPlayers.Size = new System.Drawing.Size(315, 276);
            this.lbshowPlayers.TabIndex = 8;
            this.lbshowPlayers.SelectedIndexChanged += new System.EventHandler(this.lbshowPlayers_SelectedIndexChanged);
            this.lbshowPlayers.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lbshowPlayers_MouseDoubleClick);
            // 
            // btnAddPlayer
            // 
            this.btnAddPlayer.Location = new System.Drawing.Point(56, 139);
            this.btnAddPlayer.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddPlayer.Name = "btnAddPlayer";
            this.btnAddPlayer.Size = new System.Drawing.Size(136, 39);
            this.btnAddPlayer.TabIndex = 9;
            this.btnAddPlayer.Text = "Add a player";
            this.ButtonInfo.SetToolTip(this.btnAddPlayer, "To add a player fill the information above.");
            this.btnAddPlayer.UseVisualStyleBackColor = true;
            this.btnAddPlayer.Click += new System.EventHandler(this.btnAddPlayer_Click);
            this.btnAddPlayer.MouseHover += new System.EventHandler(this.btnAddPlayer_MouseHover);
            // 
            // btnRemovePlayer
            // 
            this.btnRemovePlayer.Location = new System.Drawing.Point(58, 217);
            this.btnRemovePlayer.Margin = new System.Windows.Forms.Padding(4);
            this.btnRemovePlayer.Name = "btnRemovePlayer";
            this.btnRemovePlayer.Size = new System.Drawing.Size(133, 39);
            this.btnRemovePlayer.TabIndex = 15;
            this.btnRemovePlayer.Text = "Remove a player";
            this.ButtonInfo.SetToolTip(this.btnRemovePlayer, "To remove a player select it from the list.\r\nPlayers can be completely removed on" +
        "ly from the list of available players.");
            this.btnRemovePlayer.UseVisualStyleBackColor = true;
            this.btnRemovePlayer.Click += new System.EventHandler(this.btnRemovePlayer_Click);
            // 
            // btnEditPlayer
            // 
            this.btnEditPlayer.Location = new System.Drawing.Point(60, 293);
            this.btnEditPlayer.Name = "btnEditPlayer";
            this.btnEditPlayer.Size = new System.Drawing.Size(132, 39);
            this.btnEditPlayer.TabIndex = 17;
            this.btnEditPlayer.Text = "Edit ";
            this.ButtonInfo.SetToolTip(this.btnEditPlayer, "To edit a player double click on a selected player to retrieve his information. \r" +
        "\nThen edit it and use this button. You cannot edit a players\' name");
            this.btnEditPlayer.UseVisualStyleBackColor = true;
            this.btnEditPlayer.Click += new System.EventHandler(this.btnEditPlayer_Click);
            // 
            // lbShowPlayersInTeam
            // 
            this.lbShowPlayersInTeam.FormattingEnabled = true;
            this.lbShowPlayersInTeam.ItemHeight = 16;
            this.lbShowPlayersInTeam.Location = new System.Drawing.Point(756, 97);
            this.lbShowPlayersInTeam.Margin = new System.Windows.Forms.Padding(4);
            this.lbShowPlayersInTeam.Name = "lbShowPlayersInTeam";
            this.lbShowPlayersInTeam.Size = new System.Drawing.Size(315, 276);
            this.lbShowPlayersInTeam.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(840, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 17);
            this.label4.TabIndex = 20;
            this.label4.Text = "Players in the team";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(325, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 17);
            this.label5.TabIndex = 21;
            this.label5.Text = "Available players";
            // 
            // btnAddToTeam
            // 
            this.btnAddToTeam.Location = new System.Drawing.Point(595, 118);
            this.btnAddToTeam.Name = "btnAddToTeam";
            this.btnAddToTeam.Size = new System.Drawing.Size(115, 82);
            this.btnAddToTeam.TabIndex = 22;
            this.btnAddToTeam.Text = "Add selected available player to a team";
            this.ButtonInfo.SetToolTip(this.btnAddToTeam, "Puts a selected available player in a team.");
            this.btnAddToTeam.UseVisualStyleBackColor = true;
            this.btnAddToTeam.Click += new System.EventHandler(this.btnAddToTeam_Click);
            // 
            // cbPosition
            // 
            this.cbPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPosition.FormattingEnabled = true;
            this.cbPosition.Items.AddRange(new object[] {
            "Attacker",
            "Quarterback",
            "Goalkeeper"});
            this.cbPosition.Location = new System.Drawing.Point(398, 50);
            this.cbPosition.Name = "cbPosition";
            this.cbPosition.Size = new System.Drawing.Size(147, 24);
            this.cbPosition.TabIndex = 23;
            // 
            // btnRemoveFromTeam
            // 
            this.btnRemoveFromTeam.Location = new System.Drawing.Point(1101, 118);
            this.btnRemoveFromTeam.Name = "btnRemoveFromTeam";
            this.btnRemoveFromTeam.Size = new System.Drawing.Size(115, 81);
            this.btnRemoveFromTeam.TabIndex = 24;
            this.btnRemoveFromTeam.Text = "Remove selected player from the team.";
            this.ButtonInfo.SetToolTip(this.btnRemoveFromTeam, "Removes a selected player from the team.");
            this.btnRemoveFromTeam.UseVisualStyleBackColor = true;
            this.btnRemoveFromTeam.Click += new System.EventHandler(this.btnRemoveFromTeam_Click);
            // 
            // btnRemoveAllFromTeam
            // 
            this.btnRemoveAllFromTeam.Location = new System.Drawing.Point(1101, 244);
            this.btnRemoveAllFromTeam.Name = "btnRemoveAllFromTeam";
            this.btnRemoveAllFromTeam.Size = new System.Drawing.Size(115, 71);
            this.btnRemoveAllFromTeam.TabIndex = 26;
            this.btnRemoveAllFromTeam.Text = "Remove all players from the team";
            this.ButtonInfo.SetToolTip(this.btnRemoveAllFromTeam, "Removes all players from the team.");
            this.btnRemoveAllFromTeam.UseVisualStyleBackColor = true;
            this.btnRemoveAllFromTeam.Click += new System.EventHandler(this.btnRemoveAllFromTeam_Click);
            // 
            // btnAddAllToTeam
            // 
            this.btnAddAllToTeam.Location = new System.Drawing.Point(595, 245);
            this.btnAddAllToTeam.Name = "btnAddAllToTeam";
            this.btnAddAllToTeam.Size = new System.Drawing.Size(115, 71);
            this.btnAddAllToTeam.TabIndex = 28;
            this.btnAddAllToTeam.Text = "Add all players to the team";
            this.ButtonInfo.SetToolTip(this.btnAddAllToTeam, "Puts all available players in the team.");
            this.btnAddAllToTeam.UseVisualStyleBackColor = true;
            this.btnAddAllToTeam.Click += new System.EventHandler(this.btnAddAllToTeam_Click);
            // 
            // btnCreateTeam
            // 
            this.btnCreateTeam.Location = new System.Drawing.Point(1078, 469);
            this.btnCreateTeam.Name = "btnCreateTeam";
            this.btnCreateTeam.Size = new System.Drawing.Size(98, 54);
            this.btnCreateTeam.TabIndex = 29;
            this.btnCreateTeam.Text = "Create team";
            this.btnCreateTeam.UseVisualStyleBackColor = true;
            this.btnCreateTeam.Click += new System.EventHandler(this.btnCreateTeam_Click);
            // 
            // cbFormation
            // 
            this.cbFormation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFormation.FormattingEnabled = true;
            this.cbFormation.Items.AddRange(new object[] {
            "1      -      5      -      5",
            "1      -      3      -      7",
            "1      -      7      -      3"});
            this.cbFormation.Location = new System.Drawing.Point(882, 422);
            this.cbFormation.Name = "cbFormation";
            this.cbFormation.Size = new System.Drawing.Size(162, 24);
            this.cbFormation.TabIndex = 30;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(753, 425);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 17);
            this.label6.TabIndex = 31;
            this.label6.Text = "Choose formation:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(996, 399);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 17);
            this.label7.TabIndex = 32;
            this.label7.Text = "Atck";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(928, 399);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 17);
            this.label8.TabIndex = 33;
            this.label8.Text = "Quatrb";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(879, 399);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 17);
            this.label9.TabIndex = 34;
            this.label9.Text = "Gkpr";
            // 
            // lbAllTeams
            // 
            this.lbAllTeams.FormattingEnabled = true;
            this.lbAllTeams.ItemHeight = 16;
            this.lbAllTeams.Location = new System.Drawing.Point(28, 603);
            this.lbAllTeams.Name = "lbAllTeams";
            this.lbAllTeams.Size = new System.Drawing.Size(282, 84);
            this.lbAllTeams.TabIndex = 35;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 563);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 17);
            this.label10.TabIndex = 36;
            this.label10.Text = "Teams";
            // 
            // btnViewSelectedTeam
            // 
            this.btnViewSelectedTeam.Location = new System.Drawing.Point(328, 634);
            this.btnViewSelectedTeam.Name = "btnViewSelectedTeam";
            this.btnViewSelectedTeam.Size = new System.Drawing.Size(75, 28);
            this.btnViewSelectedTeam.TabIndex = 37;
            this.btnViewSelectedTeam.Text = "View";
            this.ButtonInfo.SetToolTip(this.btnViewSelectedTeam, "Select a team to view it.");
            this.btnViewSelectedTeam.UseVisualStyleBackColor = true;
            this.btnViewSelectedTeam.Click += new System.EventHandler(this.btnViewSelectedTeam_Click);
            // 
            // lbViewPlayersInTeam
            // 
            this.lbViewPlayersInTeam.FormattingEnabled = true;
            this.lbViewPlayersInTeam.ItemHeight = 16;
            this.lbViewPlayersInTeam.Location = new System.Drawing.Point(463, 476);
            this.lbViewPlayersInTeam.Name = "lbViewPlayersInTeam";
            this.lbViewPlayersInTeam.Size = new System.Drawing.Size(207, 228);
            this.lbViewPlayersInTeam.TabIndex = 38;
            this.lbViewPlayersInTeam.Visible = false;
            // 
            // btnClearView
            // 
            this.btnClearView.Location = new System.Drawing.Point(694, 646);
            this.btnClearView.Name = "btnClearView";
            this.btnClearView.Size = new System.Drawing.Size(88, 41);
            this.btnClearView.TabIndex = 39;
            this.btnClearView.Text = "Clear view";
            this.btnClearView.UseVisualStyleBackColor = true;
            this.btnClearView.Visible = false;
            this.btnClearView.Click += new System.EventHandler(this.btnClearView_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(762, 488);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(124, 17);
            this.label11.TabIndex = 40;
            this.label11.Text = "Enter team name: ";
            // 
            // txtbTeamName
            // 
            this.txtbTeamName.Location = new System.Drawing.Point(892, 485);
            this.txtbTeamName.Name = "txtbTeamName";
            this.txtbTeamName.Size = new System.Drawing.Size(126, 22);
            this.txtbTeamName.TabIndex = 41;
            // 
            // ButtonInfo
            // 
            this.ButtonInfo.AutoPopDelay = 10000;
            this.ButtonInfo.InitialDelay = 500;
            this.ButtonInfo.ReshowDelay = 100;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1357, 752);
            this.Controls.Add(this.txtbTeamName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnClearView);
            this.Controls.Add(this.lbViewPlayersInTeam);
            this.Controls.Add(this.btnViewSelectedTeam);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lbAllTeams);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbFormation);
            this.Controls.Add(this.btnCreateTeam);
            this.Controls.Add(this.btnAddAllToTeam);
            this.Controls.Add(this.btnRemoveAllFromTeam);
            this.Controls.Add(this.btnRemoveFromTeam);
            this.Controls.Add(this.cbPosition);
            this.Controls.Add(this.btnAddToTeam);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbShowPlayersInTeam);
            this.Controls.Add(this.btnEditPlayer);
            this.Controls.Add(this.btnRemovePlayer);
            this.Controls.Add(this.btnAddPlayer);
            this.Controls.Add(this.lbshowPlayers);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbSemester);
            this.Controls.Add(this.txtbName);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Team Manager";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtbName;
        private System.Windows.Forms.TextBox txtbSemester;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbshowPlayers;
        private System.Windows.Forms.Button btnAddPlayer;
        private System.Windows.Forms.Button btnRemovePlayer;
        private System.Windows.Forms.Button btnEditPlayer;
        private System.Windows.Forms.ListBox lbShowPlayersInTeam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAddToTeam;
        private System.Windows.Forms.ComboBox cbPosition;
        private System.Windows.Forms.Button btnRemoveFromTeam;
        private System.Windows.Forms.Button btnRemoveAllFromTeam;
        private System.Windows.Forms.Button btnAddAllToTeam;
        private System.Windows.Forms.Button btnCreateTeam;
        private System.Windows.Forms.ComboBox cbFormation;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox lbAllTeams;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnViewSelectedTeam;
        private System.Windows.Forms.ListBox lbViewPlayersInTeam;
        private System.Windows.Forms.Button btnClearView;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbTeamName;
        private System.Windows.Forms.ToolTip ButtonInfo;
    }
}

